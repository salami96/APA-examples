//
//  ViewController.swift
//  aula3 - autolayout
//
//  Created by Gabriel Zanatto Salami on 09/05/19.
//  Copyright © 2019 Gabriel Zanatto Salami. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

