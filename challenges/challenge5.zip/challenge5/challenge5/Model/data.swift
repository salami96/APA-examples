//
//  data.swift
//  challenge5
//
//  Created by Gabriel Zanatto Salami on 14/05/19.
//  Copyright © 2019 Gabriel Zanatto Salami. All rights reserved.
//

import Foundation
struct Data{
    var email: String
    var modo: String
}
