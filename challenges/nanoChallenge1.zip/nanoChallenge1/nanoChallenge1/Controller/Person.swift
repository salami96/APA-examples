//
//  Person.swift
//  nanoChallenge1
//
//  Created by Gabriel Zanatto Salami on 15/05/19.
//  Copyright © 2019 Gabriel Zanatto Salami. All rights reserved.
//

import Foundation

struct Pessoa {
    var nome: String
    var emprego: String
    var foto: String
    var historico: String
    
    func dadosPessoaMinimos() -> (String, String){
        return (nome, foto)
    }
}
