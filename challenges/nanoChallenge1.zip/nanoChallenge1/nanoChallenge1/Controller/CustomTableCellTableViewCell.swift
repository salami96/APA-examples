//
//  CustomTableCellTableViewCell.swift
//  nanoChallenge1
//
//  Created by Gabriel Zanatto Salami on 15/05/19.
//  Copyright © 2019 Gabriel Zanatto Salami. All rights reserved.
//

import UIKit

class CustomTableCellTableViewCell: UITableViewCell {
    @IBOutlet weak var verDepois: UIButton!
    @IBOutlet weak var favorito: UIButton!
    @IBOutlet weak var painel: UILabel!
    @IBOutlet weak var hora: UILabel!
    @IBOutlet weak var foto: UIImageView!
    @IBOutlet weak var nome: UILabel!
    @IBOutlet weak var titulo: UILabel!
    
    //var palestra = Palestras? = nil
    var favoriteImages = ("ic_favorite","ic_favorite_over")
    var timeImages = ("ic_time","ic_time_over")
    var favoriteIsActive = false
    var timeIsActive = false
    
    
//    override var selectionStyle: UITableViewCell.SelectionStyle

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func returnDataToModel(){
        //palestra
    }
    
    @IBAction func favoritar(_ sender: UIButton) {
        if favoriteIsActive {
            favorito.setImage(UIImage(named: favoriteImages.0), for: UIControl.State.normal)
            favoriteIsActive = false
        } else {
            favorito.setImage(UIImage(named: favoriteImages.1), for: UIControl.State.normal)
            favoriteIsActive = true
        }
    }
    @IBAction func adiar(_ sender: UIButton) {
        if timeIsActive {
            verDepois.setImage(UIImage(named: timeImages.0), for: UIControl.State.normal)
            timeIsActive = false
        } else {
            verDepois.setImage(UIImage(named: timeImages.1), for: UIControl.State.normal)
            timeIsActive = true
        }
    }
    
    
    
    

}
