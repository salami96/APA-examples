//
//  Palestras.swift
//  nanoChallenge1
//
//  Created by Gabriel Zanatto Salami on 15/05/19.
//  Copyright © 2019 Gabriel Zanatto Salami. All rights reserved.
//

import Foundation

struct Palestras{
    var painel: String
    var hora: String
    var titulo: String
    var palestrante: Pessoa
    var descricao: String
    var favorito: Bool
    var lembrete: Bool
}
