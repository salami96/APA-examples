//
//  ViewController.swift
//  nanoChallenge1
//
//  Created by Gabriel Zanatto Salami on 15/05/19.
//  Copyright © 2019 Gabriel Zanatto Salami. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var pessoas = [Pessoa] ()
    public var palestras = [Palestras] ()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pessoas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? CustomTableCellTableViewCell else { fatalError() }
        
        cell.painel.text = palestras[indexPath.row].painel
        cell.hora.text = palestras[indexPath.row].hora
        cell.favorito.setImage(UIImage(named: palestras[indexPath.row].favorito ? "ic_favorite_over" : "ic_favorite"), for: UIControl.State.normal)
        cell.verDepois.setImage(UIImage(named: palestras[indexPath.row].lembrete ? "ic_time_over" : "ic_time"), for: UIControl.State.normal)
        cell.foto.image = UIImage(named: palestras[indexPath.row].palestrante.foto)
        cell.titulo.text = palestras[indexPath.row].titulo
        cell.nome.text = palestras[indexPath.row].palestrante.nome
        
//        cell.palestra = palestras[indexPath.row]
        
        switch cell.painel.text {
            case "Stage 01":
                cell.painel.backgroundColor = #colorLiteral(red: 0.7176470588, green: 0.3294117647, blue: 0.6352941176, alpha: 1)
            case "Stage 02":
                cell.painel.backgroundColor = #colorLiteral(red: 0.07843137255, green: 0.5450980392, blue: 0.5882352941, alpha: 1)
            case "Stage 03":
                cell.painel.backgroundColor = #colorLiteral(red: 0.2941176471, green: 0.7254901961, blue: 0.4078431373, alpha: 1)
            default:
                print("Nao achor a cor do painel")
        }
        cell.painel.layer.cornerRadius = 9
        cell.painel.layer.masksToBounds = true
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "detail", sender: palestras[indexPath.row])
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let nextScreenVC = segue.destination as? DetalhesViewController, let data = sender as? Palestras {
            nextScreenVC.palestra = data
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 190
    }
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        pessoas =
            [
                Pessoa(nome: "Felipe Domeneguetti", emprego: "Art Director, UI Design - Softplan", foto: "img_felipe", historico: "With more than 10 years of experience in the field, I worked for many years as graphic designer and art director in advertising agencies in São Paulo, in recent years my focus and studies are in the areas of interface design and user experience, I believe listening and understanding the needs of the user or client throughout the journey is critical to creating a more valuable work for your audience."),
                Pessoa(nome: "Samyra Ribeiro", emprego: "Art Director, UI Design - Huge", foto: "img_samyra", historico: "She directed and founded the School of Design of Interaction of Veritas University and is currently a professor at UX of Lead University. While his initial training is as a journalist, his work has focused on the intersection of culture, technology and design. Ana directed the Brand Innovation area in Almabrands, Chile, where she led strategic projects with brands such as Falabella, Banco de Chile, Lan Chile and others."),
                Pessoa(nome: "Izabela de Fátima", emprego: "Front-end Development - Dell", foto: "img_isabela", historico: "I am passionate about design, technology, innovation and its possibilities.\n I work with front-end development since 2008. The passion for design was born in the same year, and since then I have always been looking for more knowledge and techniques to present the best solutions to my clients."),
                Pessoa(nome: "Priscila Alcantara", emprego: "Consulting at UX Design - Catarinas Design", foto: "img_prscila", historico: "Júlia Ghisi holds a degree in Graphic Design from the Federal University of Santa Catarina, postgraduate degree in User-Centered Design and Service Design at Universidade Positivo. Director of project planning and UX design consultant at Catarinas Interaction Design."),
                Pessoa(nome: "Arthur silva", emprego: "UX Specialist - Squad", foto: "img_arthur", historico: "Graduated in Design, postgraduate in Marketing and Digital Design and Master in Management of Creative Economy by ESPM-RJ. I have worked at Globo.com, Virtual Shelf and at Huge, where I helped develop digital products for clients in Brazil and USA, such as Discovery, Nestlé, Estadão and the well."),
                Pessoa(nome: "Carolina Sepúlveda", emprego: "UX Lead and Product Designer - QuintoAndar", foto: "img_carolina", historico: "Designer in the area of ​​technology, believes that a nice experience is surrounded by products and services resulting from a true intersection between meeting real customer needs, sustainable business models and technical feasibility. It breathes design culture and is always committed to solving complex ecosystem problems."),
                Pessoa(nome: "Katherine Exss", emprego: "Product Manager - Sympla", foto: "img_katherine", historico: "Designer and production engineer by training. With a stint at Stanford University and a fan of courses ranging from futurism to shoe design, he has experience in designing business models and roadmaps for disruptive technologies and product management. She is currently the product manager responsible for the mobile area at Sympla."),
                Pessoa(nome: "Rodrigo Ramirez", emprego: "Visual / Interaction Designer - Sidia Samsung Technology Institute", foto: "img_rodrigo", historico: "I am currently Visual / Interaction Designer at Samsung Sidia Technology Institute. And I have worked on Virtual Reality projects, my main job that I have been involved with is VR Healthcare, developed in partnership with Albert Einstein Hospital."),
                Pessoa(nome: "Eleny Meiborg", emprego: "Co-Founder and Data Product Designer - Punk Metrics", foto: "img_eleny", historico: "Passionate about building elegant, aesthetically engaging and above all useful digital artifacts. Founder and leader of Semantics. Mentor on the ACE startup accelerator and TechMall (MG). Local Leader of IxDA SP and Member of the Brazilian Society of Information Design. I studied in the master's degree in Cognitive Psychology (UFPE) and I am studying in Information Science (USP)."),
                Pessoa(nome: "Thaís Falabella Ricaldoni", emprego: "UX Designer - Globosat", foto: "img_thais", historico: "I have been a UX Designer for 6 years with MBA in Design Thinking and Entrepreneurship. I spent a year living in San Francisco (USA) to experience the warm and charming market of Silicon Valley. There I learned to have strong contact with teams of Dev (mainly women who program <3) and I could see the boom of new platforms and startups working with innovation.")
        ]
        palestras =
            [
                Palestras(painel: "Stage 01", hora: "9:00", titulo: "Intrapreneurship: the power of innovation in public management", palestrante: pessoas[0], descricao: "In 2017 I participated in an intrapreneurship and innovation program, the objective was to create solutions that would increase the revenues of municipalities. Using techniques such as Design Thinking, User Experience, Machine Learning, NABC, was born InnovaCity, a solution for the inspection of Works and Municipal Postures.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 02", hora: "11:00", titulo: "Search for UX - how to manage this area in a large company?", palestrante: pessoas[1], descricao: "User researcher is already a job-description established in the UX market. However, this position only gained department status in large companies where the UX research area has consolidated as an independent and necessary sector. I share here the experience of the management process of this area in a great news portal.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 03", hora: "12:00", titulo: "Accessibility in the Ifood: from research to the creation of culture", palestrante: pessoas[2], descricao: "There are approximately 285 million people with visual impairments in the world. Do you know if your product is ready to receive them? We share our learning developing an affordable product for screen readers and teach the first steps for you to do the same in your company.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 01", hora: "14:00", titulo: "Psychology as a Design Tool: An Experiment on Decision", palestrante: pessoas[3], descricao: "Interface design benefits from multiple disciplines to design effective experiences. One of them is psychology. This article describes an experiment carried out in order to verify, in a primary way, if the cognitive bias of the confirmation can influence, albeit slightly, the decision making in shopping sites.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 02", hora: "14:30", titulo: "Corporate Gamification: board game as an artifact for awareness", palestrante: pessoas[4], descricao: "The present project aims to present a board game model created to present results of an exploratory study using corporate gamification, which for its ability to create meaningful interactions in the business context, increasing team engagement and making the process of analysis more empathic.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 03", hora: "15:30", titulo: "Process of design and co-creation of the first community", palestrante: pessoas[5], descricao: "In January 2018 the first community of women experienced in Latin American users was created in Chile, through a process of co-design based on collaborative work and constant feedback from the participants. In this way, they have managed to produce 4 products / mvps for the benefit of the community.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 01", hora: "16:30", titulo: "Rethinking the glass industry: service design for glassware Chile", palestrante: pessoas[6], descricao: "Cristalerías Chile is the most relevant glass factory in the country, but its customers are dissatisfied with the service and perceive them as not very innovative. Through a service design consultancy, we detect its main pains and design a strategy that rethinks its vision, ecological impact, use of technology and relationship with customers.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 02", hora: "19:00", titulo: "Visual information design for the experience of emergency", palestrante: pessoas[7], descricao: "In a critical human experience such as emergency, having clear and opportune information is a key for reduces uncertainty. A well-designed information should enhance preparedness, may contribute to decision making and support resilience. Specifically, Icons are ubiquitous graphic tools for the representation of multiple scenarios or actions. This paper focuses on the design and testing of icons as a language for emergency.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 03", hora: "20:00", titulo: "Designers future proof skillet? A short-term ability to work with AI", palestrante: pessoas[8], descricao: "This paper presents a preliminary analysis between skills and skills needed by designers for the transition towards the impact of upcoming technologies in the labor market, especially the ones related to artificial intelligence, by giving a solid background of the technology and in consequence tries to prepare designers for future job requirements.", favorito: false, lembrete: false),
                Palestras(painel: "Stage 01", hora: "9:00", titulo: "Design-driven innovation in small businesses: innovation's tactical canvas", palestrante: pessoas[9], descricao: "How to use Design Thinking to help small businesses innovate? Focusing on this challenge, the Tactical Canvas of Innovation was elaborated, a roadmap for, from a problem, to reach the effective implementation of innovations. The presentation will cover the elaboration of the tool, its operation and application cases.", favorito: false, lembrete: false),
        ]
    }
    


    
}



