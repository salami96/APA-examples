//
//  DetalhesViewController.swift
//  nanoChallenge1
//
//  Created by Gabriel Zanatto Salami on 16/05/19.
//  Copyright © 2019 Gabriel Zanatto Salami. All rights reserved.
//

import UIKit

class DetalhesViewController: UIViewController {
    
    @IBOutlet weak var painel: UILabel!
    @IBOutlet weak var hora: UILabel!
    @IBOutlet weak var favorito: UIButton!
    @IBOutlet weak var verDepois: UIButton!
    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var descricao: UILabel!
    @IBOutlet weak var foto: UIImageView!
    @IBOutlet weak var nome: UILabel!
    @IBOutlet weak var cargo: UILabel!
    
    var favoriteImages = ("ic_favorite","ic_favorite_over")
    var timeImages = ("ic_time","ic_time_over")
    var favoriteIsActive = false
    var timeIsActive = false

    
    var palestra: Palestras? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        
        painel.text = palestra?.painel
        switch painel.text {
        case "Stage 01":
            painel.backgroundColor = #colorLiteral(red: 0.7176470588, green: 0.3294117647, blue: 0.6352941176, alpha: 1)
        case "Stage 02":
            painel.backgroundColor = #colorLiteral(red: 0.07843137255, green: 0.5450980392, blue: 0.5882352941, alpha: 1)
        case "Stage 03":
            painel.backgroundColor = #colorLiteral(red: 0.2941176471, green: 0.7254901961, blue: 0.4078431373, alpha: 1)
        default:
            print("Nao achor a cor do painel")
        }
        painel.layer.cornerRadius = 10
        painel.layer.masksToBounds = true
        
        
        hora.text = palestra?.hora
        favorito.setImage(UIImage(named: palestra!.favorito ? "ic_favorite_over" : "ic_favorite"), for: UIControl.State.normal)
        verDepois.setImage(UIImage(named: palestra!.lembrete ? "ic_time_over" : "ic_time"), for: UIControl.State.normal)
        titulo.text = palestra?.titulo
        descricao.text = palestra?.descricao
        foto.image = UIImage(named: (palestra?.palestrante.foto)!)
        nome.text = palestra?.palestrante.nome
        cargo.text = palestra?.palestrante.emprego

        // Do any additional setup after loading the view.
    }
    @IBAction func favoritar(_ sender: UIButton) {
        if favoriteIsActive {
            favorito.setImage(UIImage(named: favoriteImages.0), for: UIControl.State.normal)
            favoriteIsActive = false
        } else {
            favorito.setImage(UIImage(named: favoriteImages.1), for: UIControl.State.normal)
            favoriteIsActive = true
        }
    }
    @IBAction func adiar(_ sender: UIButton) {
        if timeIsActive {
            verDepois.setImage(UIImage(named: timeImages.0), for: UIControl.State.normal)
            timeIsActive = false
        } else {
            verDepois.setImage(UIImage(named: timeImages.1), for: UIControl.State.normal)
            timeIsActive = true
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
