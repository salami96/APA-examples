//
//  ViewControllerBlueScreen.swift
//  NavigatioTest
//
//  Created by Gabriel Zanatto Salami on 14/05/19.
//  Copyright © 2019 Gabriel Zanatto Salami. All rights reserved.
//

import UIKit

class ViewControllerBlueScreen: UIViewController {

    var backgroundColor : UIColor = .white
    
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        view.backgroundColor = backgroundColor
        
    }
    


    

}
